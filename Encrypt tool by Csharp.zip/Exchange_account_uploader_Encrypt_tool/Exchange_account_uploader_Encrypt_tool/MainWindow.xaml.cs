﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Exchange_account_uploader_Encrypt_tool
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        
        public MainWindow()
        {
            InitializeComponent();
            
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

            textBox_PlainText.DataContext = this;
            Console.WriteLine(encryptToBase64(PlainText, "sblw-3hn8-sqoy19"));
           // Console.WriteLine(encryptToBase64("dev1Connect1234", "sblw-3hn8-sqoy19"));


        }
        public static string encryptToBase64(string plainText, string key)
        {
            try
            {
                // Create a MemoryStream.
                MemoryStream mStream = new MemoryStream();
                TripleDESCryptoServiceProvider tripleDESCryptoServiceProvider = new TripleDESCryptoServiceProvider();
                tripleDESCryptoServiceProvider.Key = Encoding.ASCII.GetBytes(key);
                tripleDESCryptoServiceProvider.Padding = PaddingMode.PKCS7;//补位
                tripleDESCryptoServiceProvider.Mode = CipherMode.ECB;//CipherMode.CBC
                CryptoStream cStream = new CryptoStream(mStream,
                    tripleDESCryptoServiceProvider.CreateEncryptor(),
                    CryptoStreamMode.Write);

                // Convert the passed string to a byte array.
                byte[] toEncrypt = Encoding.UTF8.GetBytes(plainText);

                // Write the byte array to the crypto stream and flush it.
                cStream.Write(toEncrypt, 0, toEncrypt.Length);
                cStream.FlushFinalBlock();

                // Get an array of bytes from the
                // MemoryStream that holds the
                // encrypted data.
                byte[] ret = mStream.ToArray();

                // Close the streams.
                cStream.Close();
                mStream.Close();

                // Return the encrypted buffer.
                return Convert.ToBase64String(ret);
            }
            catch (CryptographicException e)
            {
                Console.WriteLine("A Cryptographic error occurred: {0}", e.Message);
                return null;
            }
        }



        public static string decryptFromBase64(string base64, string key)
        {
            try
            {
                if (String.IsNullOrEmpty(base64))
                {
                    throw new ArgumentNullException
                       ("The string which needs to be decrypted can not be null.");
                }

                // byte[] inputByteArray = Convert.FromBase64String(base64);
                // Create a new MemoryStream using the passed
                // array of encrypted data.
                MemoryStream msDecrypt = new MemoryStream(Convert.FromBase64String(base64));

                // Create a CryptoStream using the MemoryStream
                TripleDESCryptoServiceProvider tripleDESCryptoServiceProvider = new TripleDESCryptoServiceProvider();
                tripleDESCryptoServiceProvider.Key = ASCIIEncoding.ASCII.GetBytes(key);
                tripleDESCryptoServiceProvider.Padding = PaddingMode.PKCS7;//补位
                tripleDESCryptoServiceProvider.Mode = CipherMode.ECB;//CipherMode.CBC
                CryptoStream csDecrypt = new CryptoStream(msDecrypt,
                    tripleDESCryptoServiceProvider.CreateDecryptor(),
                    CryptoStreamMode.Read);

                // Create buffer to hold the decrypted data.
                byte[] fromEncrypt = new byte[Convert.FromBase64String(base64).Length];

                // Read the decrypted data out of the crypto stream
                // and place it into the temporary buffer.
                csDecrypt.Read(fromEncrypt, 0, fromEncrypt.Length);

                //Convert the buffer into a string and return it.
                return Encoding.UTF8.GetString(fromEncrypt).TrimEnd('\0');
            }
            catch (CryptographicException e)
            {
                Console.WriteLine("A Cryptographic error occurred: {0}", e.Message);
                return null;
            }
        }
    }
}
